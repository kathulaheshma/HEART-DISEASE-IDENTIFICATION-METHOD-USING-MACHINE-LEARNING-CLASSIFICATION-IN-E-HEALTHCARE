# ❤️ CardioScan AI

AI-powered cardiac scan analysis platform — React frontend + Python FastAPI backend.

---

## ⚡ Quick Start (3 Steps)

### Prerequisites
- [Node.js 18+](https://nodejs.org)
- [Python 3.10+](https://python.org)

---

### Windows

```bash
# 1. Install everything
setup.bat

# 2. Start both servers + open browser
start.bat
```

### Mac / Linux

```bash
# 1. Install everything
bash setup.sh

# 2. Start both servers + open browser
bash start.sh
```

---

### Manual (if scripts don't work)

**Terminal 1 — Backend**
```bash
cd backend
python -m venv venv

# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

**Terminal 2 — Frontend**
```bash
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173**

---

## Project Structure

```
cardioscan/
├── setup.bat / setup.sh     ← Run once to install
├── start.bat / start.sh     ← Run every time to launch
├── backend/
│   ├── main.py
│   ├── requirements.txt
│   ├── routers/             ← upload, analyze, report
│   ├── services/            ← validator, analyzer
│   └── utils/               ← schemas, helpers
└── frontend/
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── pages/           ← Home, Upload, Analysis, Report, Recent, TechDetail
        ├── components/      ← Navbar, DropZone, PatientForm, StagesPipeline, etc.
        ├── store/           ← Zustand global state
        └── api/             ← Axios client
```

---

## API

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/upload` | Upload & validate scan |
| POST | `/api/analyze` | Run analysis |
| GET  | `/docs` | Interactive API docs |
