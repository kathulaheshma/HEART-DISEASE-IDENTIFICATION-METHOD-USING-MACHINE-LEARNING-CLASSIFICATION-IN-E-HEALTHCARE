from PIL import Image

ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp"}
MIN_SIZE = 50 * 1024          # 50 KB
MAX_SIZE = 10 * 1024 * 1024   # 10 MB


def validate_file(path: str, content_type: str, size: int) -> dict:
    # Size checks
    if size < MIN_SIZE:
        return {"valid": False, "reason": f"File too small ({size // 1024}KB). Minimum is 50KB."}
    if size > MAX_SIZE:
        return {"valid": False, "reason": f"File too large ({size // 1024 // 1024}MB). Maximum is 10MB."}

    # MIME type check
    if content_type not in ALLOWED_MIME:
        return {"valid": False, "reason": f"File type '{content_type}' not accepted. Use JPG, PNG, or WebP."}

    # Image integrity check
    try:
        img = Image.open(path)
        img.verify()
    except Exception:
        return {"valid": False, "reason": "File could not be read as a valid image."}

    return {"valid": True, "reason": None}
