from fastapi import APIRouter, HTTPException
from utils.schemas import AnalyzeRequest
from services.analyzer import analyze_scan
import os

router = APIRouter()
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")


@router.post("/analyze")
async def run_analysis(req: AnalyzeRequest):
    scan_path = None
    for ext in [".jpg", ".jpeg", ".png", ".webp"]:
        p = os.path.join(UPLOAD_DIR, f"{req.scanId}{ext}")
        if os.path.exists(p):
            scan_path = p
            break

    if not scan_path:
        raise HTTPException(status_code=404, detail="Scan file not found. Please re-upload.")

    try:
        result = analyze_scan(scan_path, req.patient.model_dump())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

    return result
