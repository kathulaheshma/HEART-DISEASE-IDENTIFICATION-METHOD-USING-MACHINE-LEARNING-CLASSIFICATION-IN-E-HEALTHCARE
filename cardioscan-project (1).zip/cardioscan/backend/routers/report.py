from fastapi import APIRouter

router = APIRouter()


@router.get("/report/health")
def report_health():
    return {"status": "report service ok"}
