from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
import os, uuid, aiofiles
from services.validator import validate_file
from utils.helpers import file_hash, is_duplicate, register_hash

router = APIRouter()
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")


@router.post("/upload")
async def upload_scan(file: UploadFile = File(...)):
    ext       = os.path.splitext(file.filename or "scan.jpg")[1].lower() or ".jpg"
    scan_id   = str(uuid.uuid4())
    temp_path = os.path.join(UPLOAD_DIR, f"{scan_id}{ext}")

    contents = await file.read()

    async with aiofiles.open(temp_path, "wb") as f:
        await f.write(contents)

    # Validate
    result = validate_file(temp_path, file.content_type or "", len(contents))
    if not result["valid"]:
        os.remove(temp_path)
        raise HTTPException(status_code=422, detail=result["reason"])

    # Duplicate check
    h = file_hash(temp_path)
    if is_duplicate(h):
        os.remove(temp_path)
        raise HTTPException(status_code=409, detail="Duplicate image detected. This scan has already been uploaded.")
    register_hash(h)

    return JSONResponse({
        "scanId":   scan_id,
        "filename": file.filename,
        "size":     len(contents),
        "url":      f"/uploads/{scan_id}{ext}",
        "hash":     h,
    })


@router.delete("/upload/{scan_id}")
async def delete_scan(scan_id: str):
    for ext in [".jpg", ".jpeg", ".png", ".webp"]:
        path = os.path.join(UPLOAD_DIR, f"{scan_id}{ext}")
        if os.path.exists(path):
            os.remove(path)
            return {"deleted": True}
    raise HTTPException(status_code=404, detail="Scan not found")
