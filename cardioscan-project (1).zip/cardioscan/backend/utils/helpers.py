import hashlib

# In-memory hash registry (replace with DB for production)
_uploaded_hashes: set = set()


def file_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def is_duplicate(hash_str: str) -> bool:
    return hash_str in _uploaded_hashes


def register_hash(hash_str: str):
    _uploaded_hashes.add(hash_str)


def clear_hashes():
    _uploaded_hashes.clear()
