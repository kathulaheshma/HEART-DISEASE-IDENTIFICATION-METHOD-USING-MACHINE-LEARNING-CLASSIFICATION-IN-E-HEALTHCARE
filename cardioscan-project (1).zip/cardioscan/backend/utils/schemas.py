from pydantic import BaseModel
from typing import Optional, List


class PatientData(BaseModel):
    fullName: str
    age: int
    gender: str
    emergencyContact: Optional[str] = None
    bloodPressure: str
    heartRate: int
    oxygenSaturation: float
    height: Optional[float] = None
    weight: Optional[float] = None
    bmi: Optional[float] = None
    knownConditions: Optional[str] = None
    currentMedications: Optional[str] = None
    allergies: Optional[str] = None
    smokingStatus: Optional[str] = None
    familyHistory: Optional[str] = None
    physicianNotes: Optional[str] = None


class AnalyzeRequest(BaseModel):
    scanId: str
    patient: PatientData


class Abnormality(BaseModel):
    name: str
    severity: str
    confidence: float


class AnalysisResult(BaseModel):
    reportId: str
    riskScore: int
    riskTier: str
    clinicalStage: str
    confidence: float
    abnormalities: List[Abnormality]
    explanation: str
    recommendations: List[str]
    processingTime: float
    timestamp: str
