#!/bin/bash
echo ""
echo " ========================================"
echo "   CardioScan AI - Project Setup"
echo " ========================================"
echo ""

echo "[1/2] Setting up Python backend..."
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt --quiet
cd ..
echo " Backend ready."

echo "[2/2] Installing frontend packages..."
cd frontend
npm install --silent
cd ..
echo " Frontend ready."

echo ""
echo " ========================================"
echo "   Setup complete! Run: bash start.sh"
echo " ========================================"
echo ""
