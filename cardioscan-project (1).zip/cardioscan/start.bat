@echo off
echo.
echo  ========================================
echo    CardioScan AI - Starting Servers
echo  ========================================
echo.
echo  Backend  →  http://localhost:8000
echo  Frontend →  http://localhost:5173
echo.

:: Start backend in new window
start "CardioScan Backend" cmd /k "cd backend && venv\Scripts\activate && uvicorn main:app --reload --port 8000"

:: Wait 2 seconds then start frontend
timeout /t 2 /nobreak > nul
start "CardioScan Frontend" cmd /k "cd frontend && npm run dev"

:: Wait 3 seconds then open browser
timeout /t 3 /nobreak > nul
start http://localhost:5173

echo  Both servers started. Browser opening...
echo  Press any key to close this window.
pause > nul
