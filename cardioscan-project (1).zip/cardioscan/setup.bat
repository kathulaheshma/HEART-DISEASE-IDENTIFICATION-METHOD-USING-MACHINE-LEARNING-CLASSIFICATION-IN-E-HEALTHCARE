@echo off
echo.
echo  ========================================
echo    CardioScan AI - Project Setup
echo  ========================================
echo.

:: ── BACKEND ──────────────────────────────
echo [1/4] Setting up Python backend...
cd backend
python -m venv venv
call venv\Scripts\activate
pip install -r requirements.txt --quiet
cd ..
echo  Backend ready.

:: ── FRONTEND ─────────────────────────────
echo [2/4] Installing frontend packages...
cd frontend
npm install --silent
cd ..
echo  Frontend ready.

echo.
echo  ========================================
echo    Setup complete!
echo    Run start.bat to launch the project.
echo  ========================================
echo.
pause
