import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
  timeout: 60000,
})

export const uploadScan = (file, onProgress) => {
  const form = new FormData()
  form.append('file', file)
  return api.post('/api/upload', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: e =>
      onProgress && onProgress(Math.round((e.loaded * 100) / e.total)),
  })
}

export const runAnalysis = (scanId, patient) =>
  api.post('/api/analyze', { scanId, patient })

export const deleteScan = (scanId) =>
  api.delete(`/api/upload/${scanId}`)

export default api
