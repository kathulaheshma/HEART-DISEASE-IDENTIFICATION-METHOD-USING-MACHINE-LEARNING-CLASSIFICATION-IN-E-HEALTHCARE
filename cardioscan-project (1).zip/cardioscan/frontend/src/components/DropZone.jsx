import { useRef } from 'react'
import useStore from '../store/useStore'
import { uploadScan } from '../api/client'

export default function DropZone() {
  const fileRef = useRef()
  const { scanURL, clearScan, setScan, showToast } = useStore()

  async function handleFile(file) {
    if (!file) return
    try {
      const res = await uploadScan(file)
      const { scanId, url, hash } = res.data
      const fullURL = `${import.meta.env.VITE_API_URL || 'http://localhost:8000'}${url}`
      setScan(scanId, fullURL, hash)
      showToast('Scan Accepted', 'Cardiac scan validated successfully.', 'success')
    } catch (err) {
      const msg = err.response?.data?.detail || 'Upload failed. Please try again.'
      showToast('Upload Rejected', msg, 'error')
    }
  }

  if (scanURL) return (
    <div>
      <div style={{
        border: '1px solid var(--text3)', height: 280, position: 'relative',
        overflow: 'hidden', background: 'var(--surface)',
      }}>
        <img src={scanURL} alt="Scan" style={{ width: '100%', height: '100%', objectFit: 'contain', filter: 'grayscale(.15)' }} />
        <div style={{
          position: 'absolute', bottom: 10, left: 10, background: 'var(--bg)',
          border: '1px solid var(--border3)', padding: '3px 10px',
          fontFamily: 'var(--fm)', fontSize: 9, letterSpacing: '.15em', color: 'var(--text3)',
        }}>✓ VALIDATED</div>
      </div>
      <button className="btn-o" style={{ width: '100%', justifyContent: 'center', marginTop: 10 }}
        onClick={() => { clearScan(); fileRef.current.value = '' }}>
        ✕ Remove & Upload Different
      </button>
    </div>
  )

  return (
    <div
      style={{
        border: '1px dashed var(--border3)', height: 280,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', background: 'var(--surface)', position: 'relative',
      }}
      onClick={() => fileRef.current.click()}
      onDragOver={e => e.preventDefault()}
      onDrop={e => { e.preventDefault(); handleFile(e.dataTransfer.files[0]) }}
    >
      <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
        <div style={{ fontSize: 32, color: 'var(--text5)' }}>⊕</div>
        <div style={{ fontFamily: 'var(--fd)', fontSize: 15, color: 'var(--text3)' }}>Drop cardiac scan here</div>
        <div style={{ fontFamily: 'var(--fm)', fontSize: 10, color: 'var(--text5)', letterSpacing: '.06em' }}>JPG, PNG · 50KB – 10MB</div>
        <div style={{ fontFamily: 'var(--fm)', fontSize: 10, color: 'var(--text5)' }}>Heart CT · Cardiac MRI · Chest X-Ray</div>
      </div>
      <input ref={fileRef} type="file" accept=".jpg,.jpeg,.png,.webp"
        style={{ display: 'none' }} onChange={e => handleFile(e.target.files[0])} />
    </div>
  )
}
