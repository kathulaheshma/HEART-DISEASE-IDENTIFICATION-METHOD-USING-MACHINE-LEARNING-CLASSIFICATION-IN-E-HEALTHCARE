import { useNavigate, useLocation } from 'react-router-dom'
import useStore from '../store/useStore'

const PAGES = [
  { path: '/',         label: 'Home' },
  { path: '/upload',   label: 'Upload & Patient' },
  { path: '/analysis', label: 'Analysis' },
  { path: '/report',   label: 'Report' },
  { path: '/recent',   label: 'Recent' },
]

export default function Navbar() {
  const navigate   = useNavigate()
  const { pathname } = useLocation()
  const { isLight, toggleTheme } = useStore()

  const navBtn = (path, label) => (
    <button key={path} onClick={() => navigate(path)} style={{
      fontFamily: 'var(--fm)', fontSize: 10, fontWeight: 500,
      letterSpacing: '.1em', textTransform: 'uppercase', background: 'none', cursor: 'pointer',
      padding: '7px 13px', transition: 'all .2s',
      color:      pathname === path ? 'var(--text)'    : 'var(--text4)',
      border:     pathname === path ? '1px solid var(--border3)' : '1px solid transparent',
      background: pathname === path ? 'var(--surface2)' : 'none',
    }}>{label}</button>
  )

  return (
    <nav style={{
      background: 'var(--bg)', borderBottom: '1px solid var(--border)',
      position: 'sticky', top: 0, zIndex: 1000,
    }}>
      <div style={{
        maxWidth: 1200, margin: '0 auto', padding: '0 20px',
        height: 64, display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', gap: 12,
      }}>

        {/* Left: back + brand */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {pathname !== '/' && (
            <button className="btn-o" style={{ padding: '6px 12px', fontSize: 11 }}
              onClick={() => navigate(-1)}>← Back</button>
          )}
          <button onClick={() => navigate('/')} style={{
            display: 'flex', alignItems: 'center', gap: 9,
            background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text)',
          }}>
            <span style={{ fontSize: 18, color: 'var(--text3)' }}>♥</span>
            <span style={{ fontFamily: 'var(--fd)', fontSize: 19, fontWeight: 700, letterSpacing: '-.02em' }}>
              CardioScan
            </span>
          </button>
        </div>

        {/* Center: nav links */}
        <div className="hide-mobile" style={{ display: 'flex', gap: 2 }}>
          {PAGES.map(p => navBtn(p.path, p.label))}
        </div>

        {/* Right: theme toggle */}
        <button onClick={toggleTheme} style={{
          display: 'flex', alignItems: 'center', gap: 6,
          background: 'var(--surface2)', border: '1px solid var(--border2)',
          color: 'var(--text4)', padding: '6px 12px', fontFamily: 'var(--fm)',
          fontSize: 10, letterSpacing: '.1em', textTransform: 'uppercase',
          cursor: 'pointer', whiteSpace: 'nowrap',
        }}>
          <span style={{ transition: 'transform .4s', transform: isLight ? 'rotate(180deg)' : 'none' }}>◐</span>
          {isLight ? 'Dark Mode' : 'Light Mode'}
        </button>

      </div>
    </nav>
  )
}
