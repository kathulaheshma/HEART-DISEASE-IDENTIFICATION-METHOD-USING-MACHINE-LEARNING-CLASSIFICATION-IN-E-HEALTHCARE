import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import useStore from '../store/useStore'

const INITIAL = {
  fullName:'', age:'', gender:'', emergencyContact:'',
  bloodPressure:'', heartRate:'', oxygenSaturation:'',
  height:'', weight:'', bmi:'',
  knownConditions:'', currentMedications:'', allergies:'',
  smokingStatus:'', familyHistory:'', physicianNotes:'',
}

export default function PatientForm() {
  const { imageValid, setPatient, showToast } = useStore()
  const navigate = useNavigate()
  const [f, setF] = useState(INITIAL)

  const update = (key, val) => {
    setF(prev => {
      const next = { ...prev, [key]: val }
      const h = parseFloat(key === 'height' ? val : prev.height)
      const w = parseFloat(key === 'weight' ? val : prev.weight)
      if (h > 0 && w > 0) next.bmi = (w / (h / 100) ** 2).toFixed(1)
      return next
    })
  }

  const submit = () => {
    if (!imageValid) { showToast('No Scan', 'Please upload a valid scan first.'); return }
    const required = ['fullName','age','gender','bloodPressure','heartRate','oxygenSaturation']
    if (required.some(k => !f[k])) { showToast('Form Incomplete', 'Please fill all required fields (marked *).'); return }
    setPatient({ ...f, age: parseInt(f.age), heartRate: parseInt(f.heartRate), oxygenSaturation: parseFloat(f.oxygenSaturation) })
    navigate('/analysis')
  }

  const sectionTitle = t => (
    <div style={{ fontFamily:'var(--fd)', fontSize:18, fontWeight:700, marginBottom:18, paddingBottom:12, borderBottom:'1px solid var(--border)' }}>{t}</div>
  )
  const sectionLabel = t => (
    <div style={{ fontFamily:'var(--fm)', fontSize:9, letterSpacing:'.15em', textTransform:'uppercase', color:'var(--text5)', marginBottom:12 }}>{t}</div>
  )
  const Field = ({ label, id, required, type='text', placeholder='', options=[], readonly=false }) => (
    <div className="field-grp">
      <label className="field-lbl">{label} {required && <span className="req">*</span>}</label>
      {type === 'select' ? (
        <select className="field-inp" value={f[id]} onChange={e => update(id, e.target.value)}>
          <option value="">Select</option>
          {options.map(o => <option key={o}>{o}</option>)}
        </select>
      ) : type === 'textarea' ? (
        <textarea className="field-inp" rows={3} placeholder={placeholder} value={f[id]} onChange={e => update(id, e.target.value)} />
      ) : (
        <input className={`field-inp${readonly ? ' readonly' : ''}`} type={type}
          placeholder={placeholder} value={f[id]} readOnly={readonly}
          onChange={e => update(id, e.target.value)} />
      )}
    </div>
  )

  return (
    <div>
      {sectionTitle('Patient Information')}

      <div style={{ marginBottom: 20 }}>
        {sectionLabel('Personal Details')}
        <div className="grid-2">
          <Field label="Full Name"         id="fullName"         required placeholder="Enter full name" />
          <Field label="Age"               id="age"              required type="number" placeholder="Years" />
        </div>
        <div className="grid-2">
          <Field label="Gender"            id="gender"           required type="select" options={['Male','Female','Other']} />
          <Field label="Emergency Contact" id="emergencyContact" placeholder="Name & phone" />
        </div>
      </div>

      <div style={{ marginBottom: 20 }}>
        {sectionLabel('Vital Signs')}
        <div className="grid-3">
          <Field label="Blood Pressure"     id="bloodPressure"    required placeholder="120/80" />
          <Field label="Heart Rate (bpm)"   id="heartRate"        required type="number" placeholder="60–100" />
          <Field label="O₂ Saturation (%)"  id="oxygenSaturation" required type="number" placeholder="95–100" />
        </div>
        <div className="grid-3">
          <Field label="Height (cm)" id="height" type="number" placeholder="cm" />
          <Field label="Weight (kg)" id="weight" type="number" placeholder="kg" />
          <Field label="BMI (auto)"  id="bmi"    readonly placeholder="Auto" />
        </div>
      </div>

      <div style={{ marginBottom: 20 }}>
        {sectionLabel('Medical History')}
        <div className="grid-2">
          <Field label="Known Conditions"    id="knownConditions"    placeholder="e.g. Hypertension, Diabetes" />
          <Field label="Current Medications" id="currentMedications" placeholder="List medications" />
        </div>
        <div className="grid-2">
          <Field label="Allergies"       id="allergies"    placeholder="Drug, food allergies" />
          <Field label="Smoking Status"  id="smokingStatus" type="select" options={['Non-smoker','Former smoker','Current smoker']} />
        </div>
        <Field label="Family History" id="familyHistory" type="textarea" placeholder="Relevant family cardiac history..." />
      </div>

      <div style={{ marginBottom: 20 }}>
        {sectionLabel('Physician Notes')}
        <Field label="Clinical Notes & Observations" id="physicianNotes" type="textarea" placeholder="Enter physician notes..." />
      </div>

      <button className="btn-p" onClick={submit} disabled={!imageValid}
        style={{ width: '100%', justifyContent: 'center', padding: 15, fontSize: 13 }}>
        {imageValid ? 'Proceed to Analysis →' : 'Upload Valid Scan to Continue'}
      </button>
      {!imageValid && (
        <div style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text5)', textAlign:'center', marginTop:8 }}>
          A validated cardiac scan is required before analysis can begin.
        </div>
      )}
    </div>
  )
}
