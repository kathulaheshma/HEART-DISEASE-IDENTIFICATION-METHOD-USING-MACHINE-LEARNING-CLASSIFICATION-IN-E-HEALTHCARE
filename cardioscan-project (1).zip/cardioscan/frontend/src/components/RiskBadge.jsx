export const RISK_COLOR = {
  Critical: '#cc0000',
  High:     'var(--text)',
  Moderate: '#888',
  Low:      '#666',
}

export const STAGE_MAP = {
  Critical: 'Stage III',
  High:     'Stage II',
  Moderate: 'Stage I',
  Low:      'Stage I',
}

export function getStage(tier) {
  return STAGE_MAP[tier] || 'Stage I'
}

export function RiskBadge({ tier }) {
  const color = RISK_COLOR[tier] || 'var(--text4)'
  return (
    <span style={{
      fontFamily: 'var(--fm)', fontSize: 9, fontWeight: 600,
      letterSpacing: '.15em', textTransform: 'uppercase',
      padding: '2px 8px', border: `1px solid ${color}`,
      color, display: 'inline-block',
    }}>{tier}</span>
  )
}
