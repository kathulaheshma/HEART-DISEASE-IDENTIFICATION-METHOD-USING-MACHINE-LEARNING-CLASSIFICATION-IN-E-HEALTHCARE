import { useEffect } from 'react'
import useStore from '../store/useStore'

export default function Toast() {
  const { toast, clearToast } = useStore()

  useEffect(() => {
    if (!toast) return
    const t = setTimeout(clearToast, 4500)
    return () => clearTimeout(t)
  }, [toast])

  if (!toast) return null

  return (
    <div style={{
      position: 'fixed', bottom: 24, right: 24, zIndex: 9999,
      background: 'var(--surface2)', border: '1px solid var(--border3)',
      borderLeft: `3px solid ${toast.type === 'success' ? 'var(--text3)' : 'var(--critical)'}`,
      padding: '14px 18px', maxWidth: 340,
      fontFamily: 'var(--fm)', fontSize: 11,
      animation: 'fadeIn .3s ease',
    }}>
      <div style={{ fontWeight: 600, marginBottom: 3, letterSpacing: '.04em', color: 'var(--text)' }}>
        {toast.title}
      </div>
      <div style={{ color: 'var(--text4)', lineHeight: 1.5 }}>{toast.message}</div>
    </div>
  )
}
