import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import useStore from '../store/useStore'
import { runAnalysis } from '../api/client'

const STAGES = [
  { label: 'Image Preprocessing',     detail: 'Normalizing scan, applying CLAHE enhancement...' },
  { label: 'Cardiac Segmentation',    detail: 'Isolating cardiac region of interest...' },
  { label: 'Anomaly Detection',       detail: 'Scanning for structural irregularities...' },
  { label: 'Disease Classification',  detail: 'Running multi-label classification...' },
  { label: 'Risk & Stage Assessment', detail: 'Computing confidence scores, assigning stage...' },
  { label: 'Generating Report',       detail: 'Assembling structured diagnostic output...' },
]
const DELAYS = [1800, 2000, 2300, 1900, 1400, 1100]

export default function StagesPipeline() {
  const { scanId, patient, scanURL, setResult, addRecentAnalysis, showToast } = useStore()
  const navigate  = useNavigate()
  const [active,   setActive]   = useState(-1)
  const [done,     setDone]     = useState([])
  const [pct,      setPct]      = useState(0)
  const [started,  setStarted]  = useState(false)
  const [complete, setComplete] = useState(false)
  const [error,    setError]    = useState(null)

  const start = async () => {
    setStarted(true); setError(null)
    let result = null

    for (let i = 0; i < STAGES.length; i++) {
      setActive(i)
      if (i === STAGES.length - 1) {
        try {
          const res = await runAnalysis(scanId, patient)
          result = res.data
        } catch (err) {
          setError(err.response?.data?.detail || 'Analysis failed. Please try again.')
          setStarted(false); return
        }
      }
      await new Promise(r => setTimeout(r, DELAYS[i]))
      setDone(d => [...d, i])
      setPct(Math.round(((i + 1) / STAGES.length) * 100))
    }

    setActive(-1); setComplete(true)
    setResult(result)
    addRecentAnalysis({ patient, result, scanURL, savedAt: new Date().toISOString() })
    showToast('Analysis Complete', 'Your diagnostic report is ready.', 'success')
  }

  const Spinner = () => (
    <div style={{
      width: 14, height: 14, border: '1px solid var(--border3)',
      borderTopColor: 'var(--text)', borderRadius: '50%',
      animation: 'spin .7s linear infinite', flexShrink: 0,
    }} />
  )

  if (!started) return (
    <div style={{ background:'var(--surface2)', border:'1px solid var(--border)', padding:'48px 40px', textAlign:'center' }}>
      <div style={{ fontSize:44, color:'var(--text5)', marginBottom:14 }}>◎</div>
      <div style={{ fontFamily:'var(--fd)', fontSize:24, marginBottom:10 }}>Ready to Analyze</div>
      <div style={{ color:'var(--text4)', fontSize:13, maxWidth:380, margin:'0 auto 8px', lineHeight:1.7 }}>
        6-stage AI pipeline will process your cardiac scan. Estimated runtime: ~12 seconds.
      </div>
      <div style={{ display:'flex', flexWrap:'wrap', justifyContent:'center', gap:6, margin:'16px 0 24px' }}>
        {['CLAHE Enhancement','ROI Segmentation','Multi-Label Classification','Confidence Calibration','Stage Assignment','Report Generation'].map(s => (
          <span key={s} style={{ fontFamily:'var(--fm)', fontSize:9, padding:'3px 9px', border:'1px solid var(--border3)', color:'var(--text4)', letterSpacing:'.06em' }}>{s}</span>
        ))}
      </div>
      {error && <div style={{ color:'var(--critical)', fontFamily:'var(--fm)', fontSize:11, marginBottom:16 }}>{error}</div>}
      <button className="btn-p" style={{ padding:'14px 36px' }} onClick={start}>► Start Analysis</button>
    </div>
  )

  return (
    <div style={{ background:'var(--surface2)', border:'1px solid var(--border)', padding:28 }}>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
        <span style={{ fontFamily:'var(--fm)', fontSize:10, letterSpacing:'.15em', color:'var(--text4)' }}>
          {complete ? '✓ ANALYSIS COMPLETE' : 'PROCESSING...'}
        </span>
        <span style={{ fontFamily:'var(--fm)', fontSize:13, fontWeight:600 }}>{pct}%</span>
      </div>
      <div style={{ height:2, background:'var(--border)', marginBottom:24 }}>
        <div style={{ height:'100%', background:'var(--text)', width:pct+'%', transition:'width .4s ease' }} />
      </div>

      {STAGES.map((s, i) => (
        <div key={i} style={{
          display:'flex', alignItems:'flex-start', gap:14, padding:'11px 0',
          borderBottom: i < STAGES.length - 1 ? '1px solid var(--border)' : 'none',
          opacity: done.includes(i) ? .55 : active === i ? 1 : .3,
        }}>
          <div style={{ width:18, flexShrink:0, marginTop:2, display:'flex', alignItems:'center', justifyContent:'center' }}>
            {active === i
              ? <Spinner />
              : <span style={{ fontFamily:'var(--fm)', fontSize:13, color: done.includes(i) ? 'var(--text3)' : 'var(--border2)' }}>
                  {done.includes(i) ? '✓' : '○'}
                </span>
            }
          </div>
          <div>
            <div style={{ fontSize:13, fontWeight:500, color: active === i ? 'var(--text)' : done.includes(i) ? 'var(--text4)' : 'var(--text5)' }}>
              {s.label}
            </div>
            {active === i && (
              <div style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text5)', marginTop:3 }}>{s.detail}</div>
            )}
          </div>
        </div>
      ))}

      {complete && (
        <div style={{ marginTop:24, paddingTop:20, borderTop:'1px solid var(--border)' }}>
          <button className="btn-p" style={{ width:'100%', justifyContent:'center', padding:14 }}
            onClick={() => navigate('/report')}>View Full Report →</button>
        </div>
      )}
    </div>
  )
}
