import { create } from 'zustand'

const useStore = create((set) => ({
  // Theme
  isLight: false,
  toggleTheme: () => set(s => ({ isLight: !s.isLight })),

  // Upload
  scanId: null,
  scanURL: null,
  imageValid: false,
  usedHashes: [],
  setScan: (scanId, scanURL, hash) =>
    set(s => ({ scanId, scanURL, imageValid: true, usedHashes: [...s.usedHashes, hash] })),
  clearScan: () => set({ scanId: null, scanURL: null, imageValid: false }),

  // Patient form
  patient: null,
  setPatient: (patient) => set({ patient }),

  // Analysis result
  result: null,
  setResult: (result) => set({ result }),

  // Recent analyses (session history)
  recentAnalyses: [],
  addRecentAnalysis: (entry) =>
    set(s => ({ recentAnalyses: [entry, ...s.recentAnalyses].slice(0, 20) })),
  clearRecentAnalyses: () => set({ recentAnalyses: [] }),
  loadRecentEntry: (entry) =>
    set({ patient: entry.patient, result: entry.result, scanURL: entry.scanURL }),

  // Toast notifications
  toast: null,
  showToast: (title, message, type = 'error') =>
    set({ toast: { title, message, type, id: Date.now() } }),
  clearToast: () => set({ toast: null }),

  // Full reset for new analysis
  resetAnalysis: () =>
    set({ scanId: null, scanURL: null, imageValid: false, patient: null, result: null }),
}))

export default useStore
