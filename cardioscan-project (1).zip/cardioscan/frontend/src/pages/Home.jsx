import { useNavigate } from 'react-router-dom'

const TECHS = [
  { id:'python',   icon:'⬡', title:'Python Backend',             tag:'Core Runtime & Server',         desc:'FastAPI-powered async backend with endpoints for upload, validation, and inference.' },
  { id:'ml',       icon:'◈', title:'Machine Learning',           tag:'Model Training & Inference',    desc:'ResNet-50 fine-tuned on cardiac datasets via transfer learning for high-accuracy detection.' },
  { id:'analysis', icon:'◎', title:'Advanced Analysis System',   tag:'Multi-Layer Interpretation',    desc:'Multi-stage engine: anomaly detection, anatomical mapping, and patient data cross-referencing.' },
  { id:'imaging',  icon:'▣', title:'Medical Image Processing',   tag:'Preprocessing & Segmentation',  desc:'CLAHE enhancement, Gaussian denoising, DICOM parsing, and cardiac ROI segmentation.' },
  { id:'risk',     icon:'◉', title:'Risk Assessment Engine',     tag:'Confidence Scoring & Staging',  desc:'Calibrated 4-tier risk and 3-stage clinical classification with explainable AI.' },
  { id:'data',     icon:'▤', title:'Secure Data Management',     tag:'Encrypted Storage & Integrity', desc:'AES-256 at rest, TLS 1.3 transport, SHA-256 dedup hashing, HIPAA-aligned storage.' },
  { id:'validate', icon:'◪', title:'Smart Validation System',    tag:'Duplicate Detection',           desc:'Sequential gates: MIME type, file size, content classification, and hash-based dedup.' },
  { id:'report',   icon:'▦', title:'Diagnostic Report Generator',tag:'Structured Output & PDF Export',desc:'UUID-tracked reports with findings, stage, recommendations, and direct PDF download.' },
]

export default function Home() {
  const navigate = useNavigate()

  return (
    <div>
      {/* ── Hero ── */}
      <div style={{
        display:'grid', gridTemplateColumns:'1fr 1fr', alignItems:'center',
        gap:60, maxWidth:1200, margin:'0 auto', padding:'60px 24px',
        borderBottom:'1px solid var(--border)', minHeight:'calc(100vh - 64px)',
      }}>
        <div>
          <div className="slabel">Cardiac Diagnostic Platform v1.0</div>
          <h1 style={{ fontFamily:'var(--fd)', fontSize:'clamp(52px,7vw,96px)', fontWeight:900, lineHeight:1, letterSpacing:'-.03em', margin:'12px 0 20px' }}>
            CardioScan
          </h1>
          <p style={{ color:'var(--text3)', fontSize:15, lineHeight:1.8, marginBottom:32 }}>
            Professional-grade cardiac scan analysis system.<br/>Upload. Analyze. Diagnose. Report.
          </p>
          <div style={{ display:'flex', gap:12, marginBottom:48 }}>
            <button className="btn-p" onClick={() => navigate('/upload')}>Begin Analysis →</button>
            <button className="btn-o" onClick={() => navigate('/report')}>View Sample Report</button>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:24, paddingTop:24, borderTop:'1px solid var(--border)' }}>
            {[['4','Risk Tiers'],['3','Clinical Stages'],['8','Core Modules']].map(([n,l]) => (
              <div key={l} style={{ display:'flex', flexDirection:'column', gap:4 }}>
                <span style={{ fontFamily:'var(--fm)', fontSize:24, fontWeight:600 }}>{n}</span>
                <span style={{ fontFamily:'var(--fm)', fontSize:10, letterSpacing:'.12em', textTransform:'uppercase', color:'var(--text5)' }}>{l}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Scan animation */}
        <div style={{ display:'flex', justifyContent:'center' }}>
          <div style={{ width:260, height:260, background:'var(--surface)', border:'1px solid var(--border)', position:'relative', overflow:'hidden' }}>
            {[90,150,210].map(sz => (
              <div key={sz} style={{ position:'absolute', top:'50%', left:'50%', width:sz, height:sz, borderRadius:'50%', border:'1px solid var(--border2)', transform:'translate(-50%,-50%)', animation:'pulse 3s ease-in-out infinite' }} />
            ))}
            <div style={{ position:'absolute', left:0, right:0, height:1, background:'linear-gradient(90deg,transparent,rgba(128,128,128,.5),transparent)', animation:'scanline 3s linear infinite' }} />
            {[['top','-1px','left','-1px','2px 0 0 2px'],['top','-1px','right','-1px','2px 2px 0 0'],['bottom','-1px','left','-1px','0 0 2px 2px'],['bottom','-1px','right','-1px','0 2px 2px 0']].map(([t1,v1,t2,v2,bw],i) => (
              <div key={i} style={{ position:'absolute', width:18, height:18, [t1]:v1, [t2]:v2, borderColor:'var(--text4)', borderStyle:'solid', borderWidth:bw }} />
            ))}
          </div>
        </div>
      </div>

      {/* ── Tech Cards ── */}
      <div className="container">
        <div style={{ padding:'60px 0', borderBottom:'1px solid var(--border)' }}>
          <div className="slabel">Core Technology Stack</div>
          <div style={{ fontFamily:'var(--fd)', fontSize:32, margin:'8px 0 10px' }}>System Architecture</div>
          <div style={{ color:'var(--text4)', fontSize:14, marginBottom:36 }}>
            Eight specialized modules working in concert to deliver accurate, reliable cardiac diagnostics.
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:1, background:'var(--border)', border:'1px solid var(--border)' }}>
            {TECHS.map((t, i) => (
              <button key={t.id}
                onClick={() => navigate(`/tech/${t.id}`, { state: t })}
                onMouseEnter={e => e.currentTarget.style.background = 'var(--surface2)'}
                onMouseLeave={e => e.currentTarget.style.background = 'var(--surface)'}
                style={{ background:'var(--surface)', padding:'24px 20px', textAlign:'left', border:'none', cursor:'pointer', display:'flex', flexDirection:'column', gap:6, position:'relative' }}>
                <span style={{ position:'absolute', top:16, right:16, fontFamily:'var(--fm)', fontSize:9, color:'var(--text5)' }}>0{i+1}</span>
                <div style={{ fontSize:20, color:'var(--text3)', marginBottom:2 }}>{t.icon}</div>
                <div style={{ fontFamily:'var(--fd)', fontSize:15, fontWeight:700 }}>{t.title}</div>
                <div style={{ fontFamily:'var(--fm)', fontSize:9, color:'var(--text5)', textTransform:'uppercase', letterSpacing:'.1em' }}>{t.tag}</div>
                <div style={{ fontSize:11, color:'var(--text4)', lineHeight:1.6, marginTop:2 }}>{t.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Workflow */}
        <div style={{ padding:'60px 0' }}>
          <div className="slabel">Diagnostic Workflow</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:1, background:'var(--border)', border:'1px solid var(--border)', marginTop:28 }}>
            {[
              ['01','Upload Scan',       'Upload a cardiac CT, MRI, or X-ray. System validates content and rejects invalid inputs.'],
              ['02','Patient Details',   'Enter full patient demographics, vitals, history, and physician notes.'],
              ['03','AI Analysis',       'Multi-layer engine processes the scan and computes risk scores with confidence levels.'],
              ['04','Diagnostic Report', 'A structured clinical report is generated with findings, risk tier, stage, and recommendations.'],
            ].map(([n,t,d]) => (
              <div key={n} style={{ background:'var(--surface)', padding:'24px 20px' }}>
                <div style={{ fontFamily:'var(--fm)', fontSize:28, fontWeight:300, color:'var(--border2)', marginBottom:10 }}>{n}</div>
                <div style={{ width:28, height:1, background:'var(--border3)', marginBottom:10 }} />
                <div style={{ fontFamily:'var(--fd)', fontSize:15, fontWeight:700, marginBottom:6 }}>{t}</div>
                <div style={{ fontSize:11, color:'var(--text4)', lineHeight:1.7 }}>{d}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── CTA ── */}
      <div style={{ background:'var(--surface2)', borderTop:'1px solid var(--border)', padding:'60px 24px', textAlign:'center' }}>
        <div style={{ maxWidth:540, margin:'0 auto' }}>
          <h2 style={{ fontFamily:'var(--fd)', fontSize:28, marginBottom:12 }}>Ready to begin your cardiac analysis?</h2>
          <p style={{ color:'var(--text4)', fontSize:14, marginBottom:24, lineHeight:1.7 }}>Upload a scan and receive a professional diagnostic report in minutes.</p>
          <button className="btn-p" onClick={() => navigate('/upload')}>Start Now →</button>
        </div>
      </div>
    </div>
  )
}
