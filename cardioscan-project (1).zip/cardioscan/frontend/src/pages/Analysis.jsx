import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import useStore from '../store/useStore'
import StagesPipeline from '../components/StagesPipeline'

export default function Analysis() {
  const { patient, scanURL } = useStore()
  const navigate = useNavigate()

  useEffect(() => { if (!patient) navigate('/upload') }, [])
  if (!patient) return null

  const row = (k, v) => v ? (
    <><span style={{ color:'var(--text5)' }}>{k}</span><span style={{ color:'var(--text2)' }}>{v}</span></>
  ) : null

  return (
    <div className="page-wrap">
      <div className="slabel">Step 2 of 2</div>
      <div style={{ fontFamily:'var(--fd)', fontSize:32, margin:'8px 0 24px' }}>Cardiac Analysis Engine</div>

      <div style={{ display:'grid', gridTemplateColumns:'280px 1fr', gap:28, alignItems:'start' }}>

        {/* ── Left panel ── */}
        <div>
          {/* Scan preview */}
          <div className="slabel" style={{ marginBottom:10 }}>Uploaded Scan</div>
          <div style={{ border:'1px solid var(--border2)', height:220, background:'var(--surface)', overflow:'hidden', position:'relative' }}>
            {scanURL
              ? <img src={scanURL} alt="scan" style={{ width:'100%', height:'100%', objectFit:'contain', filter:'grayscale(.15)' }} />
              : <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', color:'var(--text5)', fontFamily:'var(--fm)', fontSize:11 }}>No scan loaded</div>
            }
          </div>

          {/* Patient summary */}
          <div style={{ background:'var(--surface2)', border:'1px solid var(--border)', padding:18, marginTop:16 }}>
            <div className="slabel" style={{ marginBottom:8 }}>Patient</div>
            <div style={{ fontFamily:'var(--fd)', fontSize:16, fontWeight:700, marginBottom:10, paddingBottom:8, borderBottom:'1px solid var(--border)' }}>
              {patient.fullName}
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'4px 10px', fontFamily:'var(--fm)', fontSize:10 }}>
              {row('Age',  patient.age)}
              {row('Gender', patient.gender)}
              {row('BP',   patient.bloodPressure)}
              {row('HR',   patient.heartRate + ' bpm')}
              {row('SpO₂', patient.oxygenSaturation + '%')}
              {row('BMI',  patient.bmi || '—')}
            </div>
          </div>

          {/* System params */}
          <div style={{ background:'var(--surface2)', border:'1px solid var(--border)', padding:16, marginTop:16 }}>
            <div style={{ fontFamily:'var(--fm)', fontSize:9, letterSpacing:'.15em', textTransform:'uppercase', color:'var(--text5)', marginBottom:12 }}>System Parameters</div>
            {[['Model','ResNet-50 v2.4'],['Dataset','CardioNet-22K'],['Sensitivity','94.2%'],['Specificity','91.8%'],['AUC Score','0.967']].map(([k,v]) => (
              <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'5px 0', borderBottom:'1px solid var(--border)' }}>
                <span style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text5)' }}>{k}</span>
                <span style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text2)', fontWeight:500 }}>{v}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Right panel ── */}
        <StagesPipeline />
      </div>
    </div>
  )
}
