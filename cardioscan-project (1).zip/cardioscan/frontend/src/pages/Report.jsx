import { useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import useStore from '../store/useStore'
import { getStage, RISK_COLOR } from '../components/RiskBadge'

const SEV_COLOR = { Normal:'#666', Mild:'#888', 'Mild–Moderate':'#888', Moderate:'var(--text)', Significant:'#cc0000' }

export default function Report() {
  const { result, patient, scanURL, showToast, resetAnalysis } = useStore()
  const navigate = useNavigate()
  const docRef   = useRef()

  if (!result || !patient) return (
    <div className="page-wrap" style={{ textAlign:'center', padding:'80px 24px' }}>
      <div style={{ fontFamily:'var(--fd)', fontSize:28, marginBottom:12 }}>No Report Available</div>
      <p style={{ color:'var(--text4)', marginBottom:24 }}>Please complete the upload and analysis workflow first.</p>
      <button className="btn-p" onClick={() => navigate('/upload')}>Begin Analysis →</button>
    </div>
  )

  const fmt   = ts => new Date(ts).toLocaleDateString('en-GB',{day:'2-digit',month:'long',year:'numeric'}) + ' at ' + new Date(ts).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})
  const stage = getStage(result.riskTier)
  const color = RISK_COLOR[result.riskTier]

  const downloadPDF = async () => {
    if (!docRef.current) return
    showToast('Preparing PDF…','Your download will start shortly.','success')
    const html2pdf = (await import('html2pdf.js')).default
    html2pdf().set({
      margin:      [10,10,10,10],
      filename:    `CardioScan-${patient.fullName.replace(/\s+/g,'-')}-${result.reportId}.pdf`,
      image:       { type:'jpeg', quality:0.97 },
      html2canvas: { scale:2, useCORS:true, backgroundColor:'#ffffff' },
      jsPDF:       { unit:'mm', format:'a4', orientation:'portrait' },
    }).from(docRef.current).save()
  }

  const Sec = ({ title }) => (
    <div style={{ fontFamily:'var(--fd)', fontSize:15, fontWeight:700, marginBottom:14, paddingBottom:10, borderBottom:'1px solid var(--border)' }}>{title}</div>
  )
  const Row = ({ k, v }) => v ? (
    <div style={{ display:'grid', gridTemplateColumns:'140px 1fr', gap:8, padding:'6px 0', borderBottom:'1px solid var(--surface2)', alignItems:'baseline' }}>
      <span style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text5)' }}>{k}</span>
      <span style={{ fontSize:12, color:'var(--text2)' }}>{v}</span>
    </div>
  ) : null

  return (
    <div>
      {/* Action bar */}
      <div style={{ borderBottom:'1px solid var(--border)', background:'var(--surface2)', padding:'14px 0' }}>
        <div style={{ maxWidth:1200, margin:'0 auto', padding:'0 24px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text4)', letterSpacing:'.1em' }}>
            REPORT ID: {result.reportId}
          </div>
          <div style={{ display:'flex', gap:10 }}>
            <button className="btn-o" onClick={downloadPDF}>⬇ Download PDF</button>
            <button className="btn-p" onClick={() => { resetAnalysis(); navigate('/upload') }}>+ New Analysis</button>
          </div>
        </div>
      </div>

      <div className="page-wrap">
        <div ref={docRef} style={{ background:'var(--surface)', border:'1px solid var(--border)', marginBottom:40 }}>

          {/* Header */}
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'22px 30px', borderBottom:'2px solid var(--text)' }}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <span style={{ fontSize:24, color:'var(--text3)' }}>♥</span>
              <div>
                <div style={{ fontFamily:'var(--fd)', fontSize:20, fontWeight:700 }}>CardioScan</div>
                <div style={{ fontFamily:'var(--fm)', fontSize:9, color:'var(--text5)', letterSpacing:'.12em', textTransform:'uppercase' }}>Cardiac Analysis Platform</div>
              </div>
            </div>
            <div style={{ fontFamily:'var(--fm)', fontSize:10, textAlign:'right', lineHeight:1.9, color:'var(--text3)' }}>
              <div><span style={{ color:'var(--text5)', marginRight:6 }}>REPORT ID</span>{result.reportId}</div>
              <div><span style={{ color:'var(--text5)', marginRight:6 }}>GENERATED</span>{fmt(result.timestamp)}</div>
              <div><span style={{ color:'var(--text5)', marginRight:6 }}>STATUS</span>FINAL</div>
            </div>
          </div>

          {/* Title bar */}
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'18px 30px', borderBottom:'1px solid var(--border)', flexWrap:'wrap', gap:8 }}>
            <div style={{ fontFamily:'var(--fd)', fontSize:24, fontWeight:700 }}>Diagnostic Report</div>
            <div style={{ fontFamily:'var(--fm)', fontSize:9, color:'var(--text5)', letterSpacing:'.1em', textTransform:'uppercase' }}>
              FOR CLINICAL REVIEW ONLY · NOT A SUBSTITUTE FOR PHYSICIAN EVALUATION
            </div>
          </div>

          <div style={{ padding:'28px 30px' }}>

            {/* Risk summary */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 200px', gap:28, background:'var(--surface2)', border:'1px solid var(--border2)', padding:24, marginBottom:24 }}>
              <div>
                <div className="slabel">Overall Risk Assessment</div>
                <div style={{ fontFamily:'var(--fd)', fontSize:44, fontWeight:700, lineHeight:1, margin:'6px 0', color }}>{result.riskTier==='Critical'?'⚠ ':''}{result.riskTier} Risk</div>
                <div style={{ fontFamily:'var(--fd)', fontSize:28, fontWeight:700, color:'#cc0000', margin:'6px 0 10px' }}>{stage}</div>
                <div style={{ fontFamily:'var(--fm)', fontSize:12, color:'var(--text3)', marginBottom:14 }}>
                  Score: {result.riskScore}/100 · Confidence: {result.confidence}% · {result.processingTime}s
                </div>
                <div style={{ height:3, background:'var(--border)', marginBottom:6 }}>
                  <div style={{ height:'100%', width:result.riskScore+'%', background:color, transition:'width .8s' }} />
                </div>
                <div style={{ display:'flex', justifyContent:'space-between', fontFamily:'var(--fm)', fontSize:8, color:'var(--text5)', textTransform:'uppercase' }}>
                  <span>Low</span><span>Moderate</span><span>High</span><span>Critical</span>
                </div>
              </div>
              <div>
                <div className="slabel" style={{ marginBottom:10 }}>Uploaded Scan</div>
                <div style={{ border:'1px solid var(--border2)', height:170, background:'var(--surface2)', overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  {scanURL
                    ? <img src={scanURL} alt="scan" style={{ width:'100%', height:'100%', objectFit:'contain', filter:'grayscale(.15)' }} />
                    : <span style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text5)' }}>No scan</span>}
                </div>
              </div>
            </div>

            {/* Patient + History */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:1, background:'var(--border)', marginBottom:1 }}>
              <div style={{ background:'var(--surface)', padding:20 }}>
                <Sec title="Patient Information" />
                <Row k="Full Name"         v={patient.fullName} />
                <Row k="Age"               v={patient.age} />
                <Row k="Gender"            v={patient.gender} />
                <Row k="Emergency Contact" v={patient.emergencyContact} />
                <Row k="Blood Pressure"    v={patient.bloodPressure} />
                <Row k="Heart Rate"        v={patient.heartRate + ' bpm'} />
                <Row k="O₂ Saturation"     v={patient.oxygenSaturation + '%'} />
                <Row k="Height"            v={patient.height ? patient.height + ' cm' : null} />
                <Row k="Weight"            v={patient.weight ? patient.weight + ' kg' : null} />
                <Row k="BMI"               v={patient.bmi} />
              </div>
              <div style={{ background:'var(--surface)', padding:20 }}>
                <Sec title="Medical History" />
                <Row k="Known Conditions"    v={patient.knownConditions} />
                <Row k="Current Medications" v={patient.currentMedications} />
                <Row k="Allergies"           v={patient.allergies} />
                <Row k="Smoking Status"      v={patient.smokingStatus} />
                <Row k="Family History"      v={patient.familyHistory} />
                <div style={{ marginTop:20 }}><Sec title="Scan Metadata" /></div>
                <Row k="Report ID"        v={result.reportId} />
                <Row k="Clinical Stage"   v={stage} />
                <Row k="Processing Time"  v={result.processingTime + 's'} />
                <Row k="Model"            v="ResNet-50 v2.4" />
                <Row k="Dataset"          v="CardioNet-22K" />
              </div>
            </div>

            {/* Findings */}
            <div style={{ background:'var(--surface)', borderTop:'1px solid var(--border)', padding:20 }}>
              <Sec title="Detected Findings & Abnormalities" />
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:10 }}>
                {result.abnormalities.map((a,i) => (
                  <div key={i} style={{ background:'var(--surface2)', border:'1px solid var(--border2)', padding:14 }}>
                    <div style={{ fontSize:13, fontWeight:500, marginBottom:8 }}>{a.name}</div>
                    <div style={{ display:'flex', alignItems:'center', gap:10, fontFamily:'var(--fm)', fontSize:10 }}>
                      <span style={{ border:`1px solid ${SEV_COLOR[a.severity]||'var(--text4)'}`, color:SEV_COLOR[a.severity]||'var(--text4)', padding:'2px 8px', fontSize:9, letterSpacing:'.1em', textTransform:'uppercase' }}>{a.severity}</span>
                      <span style={{ color:'var(--text5)' }}>Conf: {a.confidence}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Interpretation */}
            <div style={{ background:'var(--surface)', borderTop:'1px solid var(--border)', padding:20 }}>
              <Sec title="Clinical Interpretation" />
              <p style={{ fontSize:13, color:'var(--text2)', lineHeight:1.8 }}>{result.explanation}</p>
            </div>

            {/* Recommendations */}
            <div style={{ background:'var(--surface)', borderTop:'1px solid var(--border)', padding:20 }}>
              <Sec title="Clinical Recommendations" />
              {result.recommendations.map((r,i) => (
                <div key={i} style={{ display:'flex', alignItems:'baseline', gap:14, padding:'10px 0', borderBottom:'1px solid var(--surface2)' }}>
                  <span style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text5)', minWidth:22 }}>{String(i+1).padStart(2,'0')}</span>
                  <span style={{ fontSize:13, color:'var(--text2)' }}>{r}</span>
                </div>
              ))}
            </div>

            {/* Physician notes */}
            {patient.physicianNotes && (
              <div style={{ background:'var(--surface)', borderTop:'1px solid var(--border)', padding:20 }}>
                <Sec title="Physician Notes" />
                <div style={{ fontSize:13, color:'var(--text3)', lineHeight:1.8, background:'var(--surface2)', padding:14, borderLeft:'2px solid var(--border3)' }}>
                  {patient.physicianNotes}
                </div>
              </div>
            )}

            {/* Footer */}
            <div style={{ marginTop:28, paddingTop:18, borderTop:'1px solid var(--border)', fontFamily:'var(--fm)', fontSize:9, color:'var(--text5)', lineHeight:1.9 }}>
              <div>This report was generated by CardioScan. Results are intended to assist — not replace — qualified medical evaluation.</div>
              <div>Report ID: {result.reportId} · Generated: {fmt(result.timestamp)}</div>
            </div>

          </div>
        </div>
      </div>
    </div>
  )
}
