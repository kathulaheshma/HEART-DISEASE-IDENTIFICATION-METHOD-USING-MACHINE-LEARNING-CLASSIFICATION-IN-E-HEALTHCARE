import DropZone from '../components/DropZone'
import PatientForm from '../components/PatientForm'

export default function Upload() {
  return (
    <div className="page-wrap">
      <div className="slabel">Step 1 of 2</div>
      <div style={{ fontFamily:'var(--fd)', fontSize:32, margin:'8px 0 10px' }}>Upload & Patient Details</div>
      <div style={{ color:'var(--text4)', fontSize:14, marginBottom:32 }}>
        Upload a cardiac scan and complete the patient profile before proceeding to analysis.
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'320px 1fr', gap:36, alignItems:'start' }}>
        {/* Left: drop zone */}
        <div>
          <div style={{ fontFamily:'var(--fd)', fontSize:18, fontWeight:700, marginBottom:18, paddingBottom:12, borderBottom:'1px solid var(--border)' }}>
            Cardiac Scan Upload
          </div>
          <DropZone />
          <div style={{ marginTop:16, background:'var(--surface2)', border:'1px solid var(--border)', padding:14 }}>
            <div style={{ fontFamily:'var(--fm)', fontSize:9, letterSpacing:'.15em', color:'var(--text5)', textTransform:'uppercase', marginBottom:8 }}>Accepted</div>
            {['✓ Heart CT Scan','✓ Cardiac MRI','✓ Chest X-Ray (Heart-focused)'].map(t => (
              <div key={t} style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text4)', padding:'2px 0' }}>{t}</div>
            ))}
            <div style={{ fontFamily:'var(--fm)', fontSize:9, letterSpacing:'.15em', color:'var(--text5)', textTransform:'uppercase', margin:'10px 0 8px' }}>Rejected</div>
            {['✕ Lung-only scans','✕ Eye / Brain scans','✕ Non-medical images','✕ Duplicate uploads'].map(t => (
              <div key={t} style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text5)', padding:'2px 0' }}>{t}</div>
            ))}
          </div>
        </div>

        {/* Right: patient form */}
        <PatientForm />
      </div>
    </div>
  )
}
