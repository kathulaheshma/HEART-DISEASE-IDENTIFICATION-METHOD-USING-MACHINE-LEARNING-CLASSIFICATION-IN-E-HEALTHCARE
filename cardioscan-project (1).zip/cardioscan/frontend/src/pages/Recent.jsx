import { useNavigate } from 'react-router-dom'
import useStore from '../store/useStore'
import { getStage, RISK_COLOR } from '../components/RiskBadge'

export default function Recent() {
  const { recentAnalyses, clearRecentAnalyses, loadRecentEntry } = useStore()
  const navigate = useNavigate()
  const fmt = ts =>
    new Date(ts).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}) + ' · ' +
    new Date(ts).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})

  return (
    <div className="page-wrap">
      <div className="slabel">Session History</div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', margin:'8px 0 28px' }}>
        <div style={{ fontFamily:'var(--fd)', fontSize:32, fontWeight:700 }}>Recent Analyses</div>
        {recentAnalyses.length > 0 && (
          <button className="btn-o" style={{ fontSize:10 }} onClick={clearRecentAnalyses}>✕ Clear All</button>
        )}
      </div>

      {recentAnalyses.length === 0 ? (
        <div style={{ background:'var(--surface2)', border:'1px solid var(--border)', padding:'60px 24px', textAlign:'center' }}>
          <div style={{ fontSize:28, color:'var(--text5)', marginBottom:12 }}>◎</div>
          <div style={{ fontFamily:'var(--fd)', fontSize:18, marginBottom:8 }}>No analyses yet</div>
          <div style={{ fontFamily:'var(--fm)', fontSize:11, color:'var(--text5)' }}>Completed analyses will appear here automatically.</div>
          <button className="btn-p" style={{ marginTop:24 }} onClick={() => navigate('/upload')}>Start Analysis →</button>
        </div>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(340px,1fr))', gap:1, background:'var(--border)', border:'1px solid var(--border)' }}>
          {recentAnalyses.map((entry, i) => {
            const color = RISK_COLOR[entry.result.riskTier]
            const stage = getStage(entry.result.riskTier)
            return (
              <div key={i}
                onClick={() => { loadRecentEntry(entry); navigate('/report') }}
                onMouseEnter={e => e.currentTarget.style.background = 'var(--surface2)'}
                onMouseLeave={e => e.currentTarget.style.background = 'var(--surface)'}
                style={{ background:'var(--surface)', padding:20, cursor:'pointer', display:'flex', gap:16, alignItems:'flex-start' }}>
                <div style={{ width:64, height:64, flexShrink:0, border:'1px solid var(--border2)', overflow:'hidden', background:'var(--surface2)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  {entry.scanURL
                    ? <img src={entry.scanURL} alt="scan" style={{ width:'100%', height:'100%', objectFit:'contain', filter:'grayscale(.2)' }} />
                    : <span style={{ fontSize:20, color:'var(--text5)' }}>♥</span>}
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontFamily:'var(--fd)', fontSize:15, fontWeight:700, marginBottom:4, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                    {entry.patient.fullName}
                  </div>
                  <div style={{ fontFamily:'var(--fm)', fontSize:10, color:'var(--text5)', marginBottom:8 }}>
                    {fmt(entry.savedAt)} · Age {entry.patient.age} · {entry.patient.gender}
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
                    <span style={{ fontFamily:'var(--fm)', fontSize:9, fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', padding:'2px 8px', border:`1px solid ${color}`, color }}>
                      {entry.result.riskTier} Risk
                    </span>
                    <span style={{ fontFamily:'var(--fm)', fontSize:9, color:'#cc0000', fontWeight:600 }}>{stage}</span>
                    <span style={{ fontFamily:'var(--fm)', fontSize:9, color:'var(--text5)' }}>Score: {entry.result.riskScore}/100</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
