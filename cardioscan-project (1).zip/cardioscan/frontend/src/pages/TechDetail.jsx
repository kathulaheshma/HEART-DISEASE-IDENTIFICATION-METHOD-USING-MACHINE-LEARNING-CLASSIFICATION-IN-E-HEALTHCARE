import { useLocation, useNavigate, useParams } from 'react-router-dom'

const DETAILS = {
  python:   { detail: "CardioScan's backend is built on Python 3.11+ with FastAPI for async endpoints. NumPy and SciPy handle numerical operations, Pillow manages image I/O, and Uvicorn serves as the ASGI runtime. All modules are containerized via Docker.", specs: ['FastAPI','Python 3.11+','NumPy & SciPy','Pillow (PIL)','Uvicorn ASGI','Docker'] },
  ml:       { detail: "The inference engine uses a ResNet-50 architecture fine-tuned via transfer learning on annotated cardiac imaging datasets. ONNX Runtime enables fast cross-platform inference. Scikit-learn handles preprocessing pipelines and metrics.", specs: ['TensorFlow / PyTorch','ResNet-50 Architecture','Transfer Learning','ONNX Runtime','Scikit-learn'] },
  analysis: { detail: "A 3-layer framework: pixel-level anomaly detection, anatomical landmark mapping, and patient data cross-referencing. The ensemble fuses image features with clinical vitals to generate calibrated risk scores.", specs: ['Ensemble Modeling','Anatomical Mapping','Contextual Risk Fusion','Anomaly Localization','Audit Logging'] },
  imaging:  { detail: "All inputs normalized through DICOM parsing, CLAHE histogram equalization, Gaussian noise reduction, and ROI segmentation. SimpleITK and OpenCV handle the full preprocessing pipeline before model inference.", specs: ['CLAHE Enhancement','Gaussian Denoising','ROI Segmentation','DICOM Support','OpenCV / SimpleITK'] },
  risk:     { detail: "Raw model probabilities calibrated via Platt scaling and isotonic regression. Results map to four risk tiers and three clinical stages. Explainable AI techniques surface the top contributing factors per prediction.", specs: ['Platt Scaling','Isotonic Regression','4-Tier + 3-Stage System','Explainable AI','Clinical Calibration'] },
  data:     { detail: "All patient data encrypted at rest with AES-256 and in transit via TLS 1.3. PostgreSQL with row-level security ensures records are accessible only by authorized sessions. SHA-256 hashing prevents duplicate processing.", specs: ['AES-256 Encryption','TLS 1.3 Transport','PostgreSQL + RLS','Signed URL Access','HIPAA-Aligned'] },
  validate: { detail: "Sequential validation gates prevent invalid input from reaching the pipeline: MIME type verification, file size enforcement (50KB–10MB), content-based cardiac classification, and SHA-256 hash comparison.", specs: ['MIME Type Verification','SHA-256 Dedup Hashing','Content Classification','File Size Enforcement','Sequential Gate Architecture'] },
  report:   { detail: "Assembles patient demographics, scan metadata, analysis results, confidence scores, abnormalities, stage classification, and recommendations into a structured clinical report. UUID tracking and PDF export included.", specs: ['RSNA-Inspired Format','UUID Report Tracking','PDF Export (html2pdf)','Session Persistence','Structured Findings Schema'] },
}

export default function TechDetail() {
  const { id }     = useParams()
  const { state }  = useLocation()
  const navigate   = useNavigate()
  const tech  = state || { title: id, tag: '', desc: '', icon: '◎' }
  const extra = DETAILS[id] || {}

  return (
    <div className="page-wrap" style={{ maxWidth:800 }}>
      <div className="slabel" style={{ marginBottom:24 }}>{tech.tag}</div>
      <div style={{ fontFamily:'var(--fd)', fontSize:56, fontWeight:900, margin:'0 0 8px', lineHeight:1 }}>{tech.icon}</div>
      <h1 style={{ fontFamily:'var(--fd)', fontSize:36, fontWeight:700, marginBottom:20 }}>{tech.title}</h1>
      <p style={{ fontSize:15, color:'var(--text3)', lineHeight:1.85, marginBottom:36 }}>{extra.detail || tech.desc}</p>

      <div className="slabel" style={{ marginBottom:14 }}>Technologies Used</div>
      <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
        {(extra.specs || []).map(s => (
          <span key={s} style={{ fontFamily:'var(--fm)', fontSize:11, padding:'5px 12px', border:'1px solid var(--border3)', color:'var(--text3)', letterSpacing:'.04em' }}>{s}</span>
        ))}
      </div>

      <div style={{ marginTop:48 }}>
        <button className="btn-o" onClick={() => navigate(-1)}>← Back to Home</button>
      </div>
    </div>
  )
}
