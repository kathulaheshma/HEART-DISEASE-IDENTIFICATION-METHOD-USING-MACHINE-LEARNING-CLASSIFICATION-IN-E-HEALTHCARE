import { Routes, Route } from 'react-router-dom'
import { useEffect } from 'react'
import useStore from './store/useStore'
import Navbar from './components/Navbar'
import Toast from './components/Toast'
import Home from './pages/Home'
import Upload from './pages/Upload'
import Analysis from './pages/Analysis'
import Report from './pages/Report'
import Recent from './pages/Recent'
import TechDetail from './pages/TechDetail'

export default function App() {
  const isLight = useStore(s => s.isLight)

  useEffect(() => {
    document.body.classList.toggle('light', isLight)
  }, [isLight])

  return (
    <>
      <Navbar />
      <Toast />
      <Routes>
        <Route path="/"         element={<Home />} />
        <Route path="/upload"   element={<Upload />} />
        <Route path="/analysis" element={<Analysis />} />
        <Route path="/report"   element={<Report />} />
        <Route path="/recent"   element={<Recent />} />
        <Route path="/tech/:id" element={<TechDetail />} />
      </Routes>
    </>
  )
}
