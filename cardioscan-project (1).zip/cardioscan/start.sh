#!/bin/bash
echo ""
echo " ========================================"
echo "   CardioScan AI - Starting Servers"
echo " ========================================"
echo ""
echo " Backend  →  http://localhost:8000"
echo " Frontend →  http://localhost:5173"
echo ""

# Start backend
cd backend
source venv/bin/activate
uvicorn main:app --reload --port 8000 &
BACKEND_PID=$!
cd ..

# Start frontend
sleep 2
cd frontend
npm run dev &
FRONTEND_PID=$!
cd ..

# Open browser
sleep 3
open http://localhost:5173 2>/dev/null || xdg-open http://localhost:5173 2>/dev/null

echo " Both servers running."
echo " Press Ctrl+C to stop everything."
echo ""

# Wait and cleanup on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null" EXIT
wait
